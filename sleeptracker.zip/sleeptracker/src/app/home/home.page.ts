import { Component, ViewChild, ElementRef, Input, OnInit } from '@angular/core';
import { SleepService } from '../services/sleep.service';
import { SleepData } from '../data/sleep-data';
import { OvernightSleepData } from '../data/overnight-sleep-data';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';
import { IonToggle, ToastController } from '@ionic/angular';

import { BLE } from '@awesome-cordova-plugins/ble/ngx';
import { HTTP } from '@awesome-cordova-plugins/http/ngx';
// import { Chart, registerables } from 'chart.js';
import Chart from 'chart.js/auto';
import { testUserAgent } from '@ionic/core/dist/types/utils/platform';
var esp32 = {
	SERVICE_UUID: "4fafc201-1fb5-459e-8fcc-c5c9c331914b",
 	CHARACTERISTIC1_UUID: "beb5483e-36e1-4688-b7f5-ea07361b26a8",
	CHARACTERISTIC2_UUID:  "688091db-1736-4179-b7ce-e42a724a6a68"
}

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

	@Input() sleepTime;
	@Input() wakeTime;
	// @Input() checked;
	@ViewChild('sleepChart') sleepChart :ElementRef;
	@ViewChild('wakeChart') wakeChart :ElementRef;
	@ViewChild('lightChart') lightChart: ElementRef;
	@ViewChild('duraChart') duraChart: ElementRef;

	timeNow = Date.now();

	list = [];

	bars1: any;
	bars2: any;
	bars3: any;
	bars4: any;
	colorArray: any;

	sleepcount = [0,0,0,0,0,0,0,0];
	wakecount = [0,0,0,0,0,0,0,0];

	value: any;

	async plotSleepData(){
		await this.sleepService.pullOvernightData().then(data=>{
			data.forEach(element=>{
			//   console.log(Math.floor(element.startTime().getHours()/3));
			  this.sleepcount[Math.floor(element.startTime().getHours()/3)]++;
			  this.wakecount[Math.floor(element.endTime().getHours()/3)]++;
			});
		});
		// console.log(this.count);
		this.createSleepChart();
		this.createWakeChart();
	}

	createSleepChart() {
		// console.log(this.count);
		// this.bars1.destroy();
		this.bars1 = new Chart(this.sleepChart.nativeElement, {
		type: 'bar',
		data: {
			labels: ['0-2', '3-5', '6-8', '9-11', '12-14', '15-17', '18-20', '21-22', '22-24'],
			datasets: [{
			label: 'times',
			data: this.sleepcount,
			backgroundColor: 'rgb(38, 194, 129)', // array should have same number of elements as number of dataset
			borderColor: 'rgb(38, 194, 129)',// array should have same number of elements as number of dataset
			borderWidth: 1
			}]
		},
		options: {
			scales: {
				y: {
					beginAtZero: true,
					ticks: {
						stepSize : 1
					}
				}
			}
		}
		});
	}

	createWakeChart() {
		// console.log(this.count);
		// this.bars2.destroy();
		this.bars2 = new Chart(this.wakeChart.nativeElement, {
		type: 'bar',
		data: {
			labels: ['0-2', '3-5', '6-8', '9-11', '12-14', '15-17', '18-20', '21-22', '22-24'],
			datasets: [{
			label: 'times',
			data: this.wakecount,
			backgroundColor: 'rgb(38, 194, 129)', // array should have same number of elements as number of dataset
			borderColor: 'rgb(38, 194, 129)',// array should have same number of elements as number of dataset
			borderWidth: 1
			}]
		},
		options: {
			scales: {
				y: {
					beginAtZero: true,
					ticks: {
						stepSize : 1
					}
				}
			}
		}
		});
	}

	async plotLightData(){
		await this.sleepService.pullLightData().then(data=>{
			this.value = data;
		});
		// console.log(this.count);
		this.createLightChart();
	}

	createLightChart(){
		// this.bars3.destroy();
		this.bars3 = new Chart(this.lightChart.nativeElement, {
			type: 'bar',
			data: {
				labels: this.value["date"],
				datasets: [{
				label: 'seconds',
				data: this.value["value"],
				backgroundColor: 'rgb(38, 194, 129)', // array should have same number of elements as number of dataset
				borderColor: 'rgb(38, 194, 129)',// array should have same number of elements as number of dataset
				borderWidth: 1,
				barPercentage: 1, // < --- here, on the dataset
				barThickness: 'flex',
				maxBarThickness: 20
				}]
			},
			options: {
				scales: {
					y: {
						beginAtZero: true,
						ticks: {
							stepSize : 1
						}
					}
				}
			}
			});
	}
	async plotDuraData(){
		await this.sleepService.pullDuraData().then(data=>{
			this.value = data;
		});
		// console.log(this.count);
		this.createDuraChart();
	}

	createDuraChart(){
		// this.bars4.destroy();
		this.bars4 = new Chart(this.duraChart.nativeElement, {
			type: 'bar',
			data: {
				labels: this.value["date"],
				datasets: [{
				label: 'hours',
				data: this.value["value"],
				backgroundColor: 'rgb(38, 194, 129)', // array should have same number of elements as number of dataset
				borderColor: 'rgb(38, 194, 129)',// array should have same number of elements as number of dataset
				borderWidth: 1,
				barPercentage: 1, // < --- here, on the dataset
				barThickness: 'flex',
				maxBarThickness: 20
				}]
			},
			options: {
				scales: {
					y: {
						beginAtZero: true,
						ticks: {
							stepSize : 1
						}
					}
				}
			}
			});
	}

	async getWeatherData(){
		await this.sleepService.pullWeatherData().then(data=>{
			this.value =data;
		})
		console.log(this.value["weather_info_str"]);
		document.getElementById("weatherText").textContent = this.value["weather_info_str"];
		document.getElementById("wearText").textContent = this.value["recommendation_msg"];
	}

	constructor(public sleepService:SleepService, public toastController: ToastController, public ble: BLE, public http: HTTP) {

	}
	
	ngOnInit() {
		// console.log(this.allSleepData);
		setInterval(this.refreshTime, 1000); // this will call refreshTime every second
		this.getWeatherData();
		// console.log(this.sleepService.getLightStatus());
		// console.log(new Date('February 18, 2021 01:03:00').toISOString());
		// this.sleepService.pushOvernightData(new OvernightSleepData(new Date('February 18, 2021 01:03:00'), new Date('February 18, 2021 09:25:00')));
		// this.createBarChart();
		// this.sleepService.pullOvernightData();
		// this.checked = parseInt(this.sleepService.getLightStatus(),10);
		// this.sleepService.sendRequestToExpress('/info').subscribe((data)=>{
		// 	console.log(data);
		// });
		// console.log("line125");
		// var temp;
		// console.log(temp = this.sleepService.pullWeatherDate());
		// console.log("liine 207")
		
		// this.http.get('http://54.219.68.25:8080/info',{},{}).then(data=>{
		// 	console.log(JSON.stringify(data.data));
		// 	console.log(JSON.parse(data.data));
		// 	console.log(JSON.parse(data.data)["name"]);
		// })
	}

	ionViewDidEnter() {
		this.plotSleepData();
		this.plotLightData();
		this.plotDuraData();
	}

	ngOnDestroy(){
		clearInterval();
	}

	/* Ionic doesn't allow bindings to static variables, so this getter can be used instead. */
	get allSleepData() {
		return SleepService.AllSleepData;
	}

	refreshTime(){
		this.timeNow = Date.now();
		// console.log(this.timeNow);
	}

	printHello(){
		console.log("Hello");
		// console.log(this.checked);
	}

	switchLightOn(){
		this.sleepService.turnOnLight();
	}

	switchLightOff(){
		this.sleepService.turnOffLight();
	}

	async sleepTimeSave(){
		if(this.sleepTime == undefined){
			const toast = await this.toastController.create({
				message: 'Please select your sleep time',
				duration: 2000
			})
			toast.present();
		}else if(this.wakeTime == undefined){
			const toast = await this.toastController.create({
				message: 'Please select your wake up time',
				duration: 2000
			})
			toast.present();
		}else if(this.wakeTime <= this.sleepTime){
			const toast = await this.toastController.create({
				message: 'Wake up time shoud not be earlier than sleep time',
				duration: 2000
			})
			toast.present();
		}else{
			this.sleepService.logOvernightData(new OvernightSleepData(new Date(this.sleepTime), new Date(this.wakeTime)));
			const toast = await this.toastController.create({
				message: 'Sleep Data Saved',
				duration: 2000
			})
			toast.present();
		}

		// console.log(new Date(this.sleepTime));

		// console.log(new OvernightSleepData(new Date(this.sleepTime), new Date(this.wakeTime)).summaryString());
	}
}
