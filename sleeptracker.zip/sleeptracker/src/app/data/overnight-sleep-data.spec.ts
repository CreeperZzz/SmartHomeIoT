import { OvernightSleepData } from './overnight-sleep-data';

describe('OvernightSleepData', () => {
  it('should create an instance', () => {
    expect(new OvernightSleepData()).toBeTruthy();
  });
});
