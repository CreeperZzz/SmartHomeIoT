import { Component, Input, OnInit } from '@angular/core';
import { SleepService } from '../services/sleep.service';
import { OvernightSleepData } from './overnight-sleep-data';
import { StanfordSleepinessData } from './stanford-sleepiness-data';
import { Storage } from '@capacitor/storage';
import { AlertController } from '@ionic/angular';


@Component({
  selector: 'app-data',
  templateUrl: './data.page.html',
  styleUrls: ['./data.page.scss'],
})
export class DataPage implements OnInit {

  @Input() display_mode:string = "all";
  data = [];
  list = [];

  constructor(public sleepService:SleepService ,public alert: AlertController) { }

  ngOnInit() {
  }

  async ionViewWillEnter(){
    // console.log("1")
    // await this.sleepService.pullOvernightData().then(data=>{
    //   data.forEach(element=>{
    //     this.data.push(element);
    //   });
    // });
    // console.log("line32");
    // console.log(this.data);
    this.data = [];
    if(this.display_mode == 'all'){
      // console.log('3');
      await this.sleepService.pullOvernightData().then(data=>{
        data.forEach(element=>{
          this.data.push(element);
        });
      });
      await this.sleepService.pullSleepinessData().then(data=>{
        data.forEach(element=>{
          this.data.push(element);
        });
      });
      // console.log(this.list);
    }else if(this.display_mode == 'overnight'){
      await this.sleepService.pullOvernightData().then(data=>{
        data.forEach(element=>{
          this.data.push(element);
        });
      });
      // this.loadOvernightStorage()
      // this.list = this.parseOvernightSleepData;
    }else if(this.display_mode == 'sleepiness'){
      await this.sleepService.pullSleepinessData().then(data=>{
        data.forEach(element=>{
          this.data.push(element);
        });
      });
      // this.loadSleepinessStorage()
      // this.list = this.parseSleepinessData;
    }
    this.list = this.parseAllData(this.data);
    // console.log(this.list)
  }
  
  parseAllData(data){
    // console.log("line43");
    // console.log(data);
    var list = []
    for(var i = 0; i<data.length; i++ ){
      var temp = data[i];
      // console.log(data);
      if(temp instanceof OvernightSleepData){
        var obj = {subtitle: "Overnight sleep record", title: temp.summaryString(), content: "On the " + temp.dateString()+ ", you sleep lasts "+temp.summaryString()};
        list.push(obj);
      }else if (temp instanceof StanfordSleepinessData){
        var obj2 = {subtitle: "Sleepiness record", title: temp.loggedAt, content: "Your sleepiness level is "+temp.summaryString()};
        list.push(obj2);
      }
    }
    // console.log("line57");
    // console.log(list);
    return list;
  }

  refresh(){
    this.ionViewWillEnter();
  }

  // loadStorage(){
  //   this.list= []
	// 	Storage.keys().then((data)=>{
	// 		return data.keys
  //   }).then((keys)=>{
  //     keys.forEach(
  //       (key)=>{
  //         Storage.get({key:key}).then((data)=>{
  //           if(key.startsWith('sleepiness')){
  //             let sleepdata = new StanfordSleepinessData(JSON.parse(data.value).loggedValue, new Date(JSON.parse(data.value).loggedAt));
  //             var obj = {subtitle: "Sleepiness record", title: sleepdata.loggedAt, content: "Your sleepiness level is "+sleepdata.summaryString()}
  //             this.list.push(obj);
  //           }else{
  //             let sleepdata = new OvernightSleepData(new Date(JSON.parse(data.value).sleepStart), new Date(JSON.parse(data.value).sleepEnd));
  //             var obj2 = {subtitle: "Overnight sleep record", title: sleepdata.summaryString(), content: "On the " + sleepdata.dateString()+ ", you sleep lasts "+sleepdata.summaryString()}
  //             this.list.push(obj2);
  //           }
  //         });
  //       }
  //     )
  //   });
  // }

  // loadOvernightStorage(){
  //   this.list= []
	// 	Storage.keys().then((data)=>{
	// 		return data.keys
  //   }).then((keys)=>{
  //     keys.forEach(
  //       (key)=>{
  //         Storage.get({key:key}).then((data)=>{
  //           if(key.startsWith('sleepiness')){
  //             // let sleepdata = new StanfordSleepinessData(JSON.parse(data.value).loggedValue, new Date(JSON.parse(data.value).loggedAt));
  //             // var obj = {subtitle: "Sleepiness record", title: sleepdata.loggedAt, content: "Your sleepiness level is "+sleepdata.summaryString()}
  //             // this.list.push(obj);
  //           }else{
  //             let sleepdata = new OvernightSleepData(new Date(JSON.parse(data.value).sleepStart), new Date(JSON.parse(data.value).sleepEnd));
  //             var obj2 = {subtitle: "Overnight sleep record", title: sleepdata.summaryString(), content: "On the " + sleepdata.dateString()+ ", you sleep lasts "+sleepdata.summaryString()}
  //             this.list.push(obj2);
  //           }
  //         });
  //       }
  //     )
  //   });
  // }

  // loadSleepinessStorage(){
  //   this.list= []
	// 	Storage.keys().then((data)=>{
	// 		return data.keys
  //   }).then((keys)=>{
  //     keys.forEach(
  //       (key)=>{
  //         Storage.get({key:key}).then((data)=>{
  //           if(key.startsWith('sleepiness')){
  //             let sleepdata = new StanfordSleepinessData(JSON.parse(data.value).loggedValue, new Date(JSON.parse(data.value).loggedAt));
  //             var obj = {subtitle: "Sleepiness record", title: sleepdata.loggedAt, content: "Your sleepiness level is "+sleepdata.summaryString()}
  //             this.list.push(obj);
  //           }
  //           // }else{
  //           //   let sleepdata = new OvernightSleepData(new Date(JSON.parse(data.value).sleepStart), new Date(JSON.parse(data.value).sleepEnd));
  //           //   var obj2 = {subtitle: "Overnight sleep record", title: sleepdata.summaryString(), content: "On the " + sleepdata.dateString()+ ", you sleep lasts "+sleepdata.summaryString()}
  //           //   this.list.push(obj2);
  //           // }
  //         });
  //       }
  //     )
  //   });
  // }


  // async clearStorage(){
  //   const alert = await this.alert.create({
  //     // cssClass: 'my-custom-class',
  //     header: 'Clear',
  //     // subHeader: 'Subtitle',
  //     message: 'Do you want to delete all records? (This can\'t be undo).',
  //     buttons: ['Cancel', {
  //       text : "Clear",
  //       role: 'clear',
  //       id: 'clear-button',
  //       handler: () => {
  //         Storage.clear();
  //         this.refresh();
  //       }
  //     }]
  //   });
  //   alert.present();
  // }

}
