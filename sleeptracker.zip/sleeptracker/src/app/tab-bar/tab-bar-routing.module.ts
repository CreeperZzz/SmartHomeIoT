import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TabBarPage } from './tab-bar.page';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/tabs/sleepTime',
    pathMatch: 'full'
  },
  {
    path: 'tabs',
    component: TabBarPage,
    children: [
      {
        path: 'sleepTime',
        children:[
          {
            path: '',
            loadChildren: () => import('../home/home.module').then( m => m.HomePageModule)
          }
        ]
      },
      {
        path: 'sleepiness',
        children:[
          {
            path: '',
            loadChildren: () => import('../sleepiness/sleepiness.module').then( m => m.SleepinessPageModule)
          }
        ]
      },
      {
        path: 'data',
        children:[
          {
            path: '',
            loadChildren: () => import('../data/data.module').then( m => m.DataPageModule)
          }
        ]
      },
      {
        path: '',
        redirectTo: '/tabs/sleepTime',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TabBarPageRoutingModule {}
