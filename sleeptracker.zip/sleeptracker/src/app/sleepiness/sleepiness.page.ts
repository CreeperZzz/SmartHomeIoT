import { Component, OnInit, Input } from '@angular/core';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';
import { ToastController } from '@ionic/angular';
import { SleepService } from '../services/sleep.service';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-sleepiness',
  templateUrl: './sleepiness.page.html',
  styleUrls: ['./sleepiness.page.scss'],
})
export class SleepinessPage implements OnInit {

  @Input() date;
  @Input() level;

  // sleepinessContent = [
  //   'Feeling active, vital, alert, or wide awake',
  //   'Functioning at high levels, but not at peak; able to concentrate',
  //   'Awake, but relaxed; responsive but not fully alert',
  //   'Somewhat foggy, let down',
  //   'Foggy; losing interest in remaining awake; slowed down',
  //   'Sleepy, woozy, fighting sleep; prefer to lie down',
  //   'No longer fighting sleep, sleep onset soon; having dream-like thoughts',
  //   'Asleep'
  // ];

  constructor(public toastController:ToastController, public sleepService:SleepService, public platform:Platform) { 

  }

  ngOnInit() {
  }

  get sleepinessContent(){
    return StanfordSleepinessData.ScaleValues[this.level];
  }

  async sleepinessSave(){
    if(this.level == undefined){
      const toast = await this.toastController.create({
        message: "Please choose your sleepiness level",
        duration: 1000
      });
      toast.present();
    }else{
      let temp = this.date;
      if(temp == undefined){
        temp = new Date();
      }
      this.sleepService.logSleepinessData(new StanfordSleepinessData(this.level,temp));			
      const toast = await this.toastController.create({
				message: 'Sleepinees Data Saved',
				duration: 1000
			})
			toast.present();
		}
  }

  get dateNow(){
    return new Date();
  }

  isIOS(){
    return this.platform.is('ios');
  }

  isAndroid(){
    return this.platform.is('android');
  }
}
