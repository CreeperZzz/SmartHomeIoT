import { Injectable } from '@angular/core';
import { SleepData } from '../data/sleep-data';
import { OvernightSleepData } from '../data/overnight-sleep-data';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';
import { Storage } from '@capacitor/storage';
// import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HTTP } from '@awesome-cordova-plugins/http/ngx';

@Injectable({
  providedIn: 'root'
})
export class SleepService {
	private static LoadDefaultData:boolean = false;
	public static AllSleepData:SleepData[] = [];
	public static AllOvernightData:OvernightSleepData[] = [];
	public static AllSleepinessData:StanfordSleepinessData[] = [];

	expressBaseUrl:string = 'http://ec2-54-219-68-25.us-west-1.compute.amazonaws.com:8080';

	constructor(private http:HTTP) {
		if(SleepService.LoadDefaultData) {
			this.addDefaultData();
		SleepService.LoadDefaultData = false;
	}
	}

	dateToISOButLocal(date) {
		return date.toLocaleString('sv').replace(' ', 'T');
	}

	private sendRequestToCloud(endpoint:string) {
		//TODO: use the injected http Service to make a get request to the Express endpoint and return the response.
		//the http service works similarly to fetch(). It may be useful to call .toPromise() on any responses.
		//update the return to instead return a Promise with the data from the Express server
		//Note: toPromise() is a deprecated function that will be removed in the future.
		//It's possible to do the assignment using lastValueFrom, but we recommend using toPromise() for now as we haven't
		//yet talked about Observables. https://indepth.dev/posts/1287/rxjs-heads-up-topromise-is-being-deprecated
		
		return this.http.get('http://54.219.68.25:8080' + endpoint,{},{}).then(data=>{
			console.log(JSON.parse(data.data));
			return JSON.parse(data.data);
		})
		// return Promise.resolve();
	}

	async pullOvernightData() {
		var list = [];
		await this.sendRequestToCloud("/sleep/pull").then(data=>{
			data.forEach(element => {
				// console.log(element);
				// console.log(element["sleep_end"]);
				// // console.log(element["sleep_start"]);
				// console.log(new Date(element["sleep_end"]))
				// console.log(new Date("2022-07-21T09:35:31"))
				// console.log(new OvernightSleepData(new Date(element["sleep_start"]),new Date(element["sleep_end"])));
				list.push(new OvernightSleepData(new Date(element["sleep_start"]),new Date(element["sleep_end"])));
			});
		});
		// console.log("line59");
		// console.log(list);
		return list;
	}

	async pullSleepinessData(){
		var list = [];
		await this.sendRequestToCloud("/sleepiness/pull").then(data=>{
			data.forEach(element => {
				// console.log(element);
				// console.log(element["sleep_end"]);
				// // console.log(element["sleep_start"]);
				// console.log(new Date(element["sleep_end"]))
				// console.log(new Date("2022-07-21T09:35:31"))
				// console.log(new OvernightSleepData(new Date(element["sleep_start"]),new Date(element["sleep_end"])));
				list.push(new StanfordSleepinessData(element["sleepiness_value"], new Date(element["track_time"])));
			});
		});
		console.log("line59");
		console.log(list);
		return list;
	}

	async pullLightData(){
		var list;
		await this.sendRequestToCloud("/light/display/light_usage").then(data=>{
			console.log("line 85");
			console.log(data);
			list =  data;
		});
		return list;
	}

	async pullDuraData(){
		var list;
		await this.sendRequestToCloud("/sleep/display/sleep_duration").then(data=>{
			// console.log("line 85");
			// console.log(data);
			list =  data;
		});
		return list;
	}	

	async pullWeatherData(){
		var list;
		await this.sendRequestToCloud("/info/weather").then(data=>{
			// console.log("line 85");
			// console.log(data);
			list =  data;
		});
		return list;
	}

	public pushOvernightData(sleepData:OvernightSleepData){
		// console.log("/sleep/upload?start_time="+this.dateToISOButLocal(sleepData.startTime())+"&end_time="+this.dateToISOButLocal(sleepData.endTime()));
		this.sendRequestToCloud("/sleep/upload?start_time="+this.dateToISOButLocal(sleepData.startTime())+"&end_time="+this.dateToISOButLocal(sleepData.endTime()))
	}

	public pushSleepinessData(sleepData:StanfordSleepinessData){
		// console.log("sleepiness/upload?track_time=2021-02-19T09:03:00&sleepiness_value=3");
		this.sendRequestToCloud("/sleepiness/upload?track_time="+this.dateToISOButLocal(sleepData.date())+"&sleepiness_value="+sleepData.getLevel());
	}

	public turnOnLight(){
		this.sendRequestToCloud('/light/api?state=on');
	}

	public turnOffLight(){
		this.sendRequestToCloud('/light/api?state=off');
	}

	public getLightStatus(){
		return this.sendRequestToCloud('/info/light');
	}

	private addDefaultData() {
		this.logOvernightData(new OvernightSleepData(new Date('February 18, 2021 01:03:00'), new Date('February 18, 2021 09:25:00')));
		this.logSleepinessData(new StanfordSleepinessData(4, new Date('February 19, 2021 14:38:00')));
		this.logOvernightData(new OvernightSleepData(new Date('February 20, 2021 23:11:00'), new Date('February 21, 2021 08:03:00')));
	}

	public logOvernightData(sleepData:OvernightSleepData) {
		SleepService.AllSleepData.push(sleepData);
		SleepService.AllOvernightData.push(sleepData);
		this.pushOvernightData(sleepData);
		// Storage.set({
		// 	key: "overnight"+sleepData.id,
		// 	value: JSON.stringify(sleepData)
		// })
	}

	public logSleepinessData(sleepData:StanfordSleepinessData) {
		SleepService.AllSleepData.push(sleepData);
		SleepService.AllSleepinessData.push(sleepData);
		this.pushSleepinessData(sleepData);
		// Storage.set({
		// 	key: "sleepiness"+sleepData.id,
		// 	value: JSON.stringify(sleepData)
		// })
	}

	// public getOvernightData(){
	// 	var list = [];
	// 	Storage.keys().then((data)=>{
	// 		data.keys.forEach((key)=>{
	// 			if( key.startsWith('overnight')){
	// 				Storage.get({key:key}).then((data)=>{
	// 					// console.log(data.value);
	// 					list.push(JSON.parse(data.value));
	// 					// console.log(list);
	// 				});
	// 			}
	// 		});
	// 	});
	// 	return list;
	// }
	// public getSleepinessData(){
	// 	var list = [];
	// 	Storage.keys().then((data)=>{
	// 		data.keys.forEach((key)=>{
	// 			if( key.startsWith('sleepiness')){
	// 				Storage.get({key:key}).then((data)=>{
	// 					// console.log(data.value);
	// 					list.push(JSON.parse(data.value));
	// 					// console.log(list);
	// 				});
	// 			}
	// 		});
	// 	});
	// 	// console.log(list);
	// 	return list;
	// }
}
