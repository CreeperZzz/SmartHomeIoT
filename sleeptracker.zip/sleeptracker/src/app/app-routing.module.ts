import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';


const routes: Routes = [
  // {
  //   path: 'home',
  //   loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  // },
  {
    path: '',
    loadChildren: () => import('./tab-bar/tab-bar.module').then(m=> m.TabBarPageModule)
    
  },
  // {
  //   path: 'data',
  //   loadChildren: () => import('./data/data.module').then( m => m.DataPageModule)
  // },
  // {
  //   path: 'sleepiness',
  //   loadChildren: () => import('./sleepiness/sleepiness.module').then( m => m.SleepinessPageModule)
  // },
  // {
  //   path: 'tab-bar',
  //   loadChildren: () => import('./tab-bar/tab-bar.module').then( m => m.TabBarPageModule)
  // },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
